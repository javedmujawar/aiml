import numpy as np
import re
import nltk
from sklearn.datasets import load_files
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt

nltk.download("stopwords")
stemmer = WordNetLemmatizer()
comment_data = load_files( r"D:\repository\python_example\AI\assignments\assignment2\data")
x, y = comment_data.data, comment_data.target
documents = []
plt.scatter(x, y)

for sen in range(0, len(x)):
    # remove all the special characters
    document = re.sub(r'\W', ' ', str(x[sen]))
    # remove all single chatacters
    document = re.sub(r'\s+[a-zA-Z]\s+', ' ', document)
    # Remove single character from the start
    document = re.sub(r'\^[a-zA-Z]\s+', ' ', document)
    # Substituting multiple spaces with single space
    document = re.sub(r'\s+', ' ', document, flags=re.I)
    # removing prefixed 'b'
    documnet = re.sub(r'^b\s+', '', document)
    # Convert to lowercase
    document = document.lower()
    # Lemmatization
    document = document.split()
    document = [stemmer.lemmatize(word) for word in document]
    document = ' '.join(document)
    documents.append(document)

tfidfconverter = TfidfVectorizer(max_features=8, min_df=5,max_df=0.7, stop_words = stopwords.words('english'))
X = tfidfconverter.fit_transform(documents).toarray()
x_train, x_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=0)
clf = KNeighborsClassifier().fit(x_train,y_train)
y_pred = clf.predict(x_test)
print(y_pred)

print("======= Report =======")
print(classification_report(y_test,y_pred))
print(confusion_matrix(y_test,y_pred))
print(accuracy_score(y_test,y_pred))
